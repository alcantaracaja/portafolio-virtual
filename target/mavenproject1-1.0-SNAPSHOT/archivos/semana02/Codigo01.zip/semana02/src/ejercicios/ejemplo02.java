
package ejercicios;

import java.util.Scanner;

public class ejemplo02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        double radio, area, longitud;
        final double PI = 3.1416; // Según fórmula dada
        
        // 2. Entrada de datos
        System.out.print("Ingrese el radio (r): ");
        radio = scanner.nextDouble();
        
        // 3. Proceso de cálculo
        area = PI * radio * radio;
        longitud = 2 * PI * radio;
        
        // 4. Salida de datos
        System.out.println("\n--- Reporte Círculo ---");
        System.out.printf("Área (A):                    %.4f\n", area);
        System.out.printf("Longitud Circunferencia (L): %.4f\n", longitud);
        
        scanner.close();
    }
}
