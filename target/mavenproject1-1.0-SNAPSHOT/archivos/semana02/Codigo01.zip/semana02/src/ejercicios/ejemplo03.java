
package ejercicios;

import java.util.Scanner;

public class ejemplo03 {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        double baseMayor, baseMenor, altura, area;
        
        // 2. Entrada de datos
        System.out.print("Ingrese la base mayor (B): ");
        baseMayor = scanner.nextDouble();
        System.out.print("Ingrese la base menor (b): ");
        baseMenor = scanner.nextDouble();
        System.out.print("Ingrese la altura (h): ");
        altura = scanner.nextDouble();
        
        // 3. Proceso de cálculo
        area = ((baseMayor + baseMenor) * altura) / 2.0;
        
        // 4. Salida de datos
        System.out.println("\n--- Reporte Trapecio ---");
        System.out.printf("Área (A): %.4f\n", area);
        
        scanner.close();
    } 
}
