
package ejercicios;

import java.util.Scanner;

public class ejemplo05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        double lado, area, volumen;
        
        // 2. Entrada de datos
        System.out.print("Ingrese la longitud del lado (a): ");
        lado = scanner.nextDouble();
        
        // 3. Proceso de cálculo
        area = 6 * lado * lado;
        volumen = lado * lado * lado;
        
        // 4. Salida de datos
        System.out.println("\n--- Reporte Cubo ---");
        System.out.printf("Área (A):    %.4f\n", area);
        System.out.printf("Volumen (V): %.4f\n", volumen);
        
        scanner.close();
    }
}
