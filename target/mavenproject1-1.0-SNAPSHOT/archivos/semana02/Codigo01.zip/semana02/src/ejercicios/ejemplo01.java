
package ejercicios;

import java.util.Scanner;

public class ejemplo01 {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        double base, altura, area, perimetro;
        
        // 2. Entrada de datos
        System.out.print("Ingrese la base (b): ");
        base = scanner.nextDouble();
        System.out.print("Ingrese la altura (h): ");
        altura = scanner.nextDouble();
        
        // 3. Proceso de cálculo
        area = base * altura;
        perimetro = 2 * (base + altura);
        
        // 4. Salida de datos
        System.out.println("\n--- Reporte Rectángulo ---");
        System.out.printf("Área (A):      %.4f\n", area);
        System.out.printf("Perímetro (P): %.4f\n", perimetro);
        
        scanner.close();
    }
}
