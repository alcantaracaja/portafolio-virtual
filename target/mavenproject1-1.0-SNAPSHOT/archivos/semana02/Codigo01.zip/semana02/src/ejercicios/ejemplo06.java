
package ejercicios;

import java.util.Scanner;

public class ejemplo06 {
  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        int dividendo, divisor, cociente, residuo;
        
        // 2. Entrada de datos
        System.out.print("Ingrese el dividendo (entero): ");
        dividendo = scanner.nextInt();
        System.out.print("Ingrese el divisor (entero): ");
        divisor = scanner.nextInt();
        
        // 3. Proceso de cálculo & 4. Salida de datos
        if (divisor == 0) {
            System.out.println("Error: La división por cero no está definida.");
        } else {
            cociente = dividendo / divisor;
            residuo = dividendo % divisor;
            
            System.out.println("\n--- Reporte División ---");
            System.out.println("Cociente: " + cociente);
            System.out.println("Residuo:  " + residuo);
        }
        
        scanner.close();
    }  
}
