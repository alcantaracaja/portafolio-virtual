
package ejercicios;

import java.util.Scanner;

public class ejemplo04 {
        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // 1. Declaración de variables
        double radio, altura, areaTotal, volumen;
        
        // 2. Entrada de datos
        System.out.print("Ingrese el radio (r): ");
        radio = scanner.nextDouble();
        System.out.print("Ingrese la altura (h): ");
        altura = scanner.nextDouble();
        
        // 3. Proceso de cálculo
        areaTotal = 2 * Math.PI * radio * (radio + altura);
        volumen = Math.PI * radio * radio * altura;
        
        // 4. Salida de datos
        System.out.println("\n--- Reporte Cilindro ---");
        System.out.printf("Área Total (A): %.4f\n", areaTotal);
        System.out.printf("Volumen (V):    %.4f\n", volumen);
        
        scanner.close();
    }

}
