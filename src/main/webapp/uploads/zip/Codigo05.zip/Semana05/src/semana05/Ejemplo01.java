/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana05;

import java.util.Scanner;

public class Ejemplo01 {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("========================================");
        System.out.println("   SERIE ARITMÉTICA: 3, 10, 17, 24...");
        System.out.println("========================================");
        
        System.out.print("Ingrese el número de términos (n): ");
        int n = scanner.nextInt();
        
        int primerTermino = 3;
        int razon = 7;
        int suma = 0;
        int terminoActual = primerTermino;
        
        System.out.println("\nSerie generada:");
        System.out.print("  ");
        
        for (int i = 1; i <= n; i++) {
            System.out.print(terminoActual);
            if (i < n) {
                System.out.print(", ");
            }
            suma += terminoActual;
            terminoActual += razon;
        }
        
        System.out.println("\n\n========================================");
        System.out.println("Número de términos: " + n);
        System.out.println("Suma total de la serie: " + suma);
        System.out.println("========================================");
        
        scanner.close();
    }
    
}
