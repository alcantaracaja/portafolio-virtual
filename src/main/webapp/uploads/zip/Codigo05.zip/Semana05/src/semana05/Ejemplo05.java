
package semana05;

import java.util.Scanner;

public class Ejemplo05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("========================================");
        System.out.println("   VENTA DE CUADERNOS ESCOLARES");
        System.out.println("========================================");
        
        String[] productos = {
            "Cuadernos LayCons",
            "Cuadernos Justus",
            "Cuadernos StanFord",
            "Cuadernos David",
            "Cuadernos College",
            "Cuadernos Alpha"
        };
        
        double[] precios = {1.50, 1.90, 3.50, 2.50, 3.00, 4.50};
        
        System.out.println("\nPRODUCTOS DISPONIBLES:");
        System.out.println("----------------------------------------");
        for (int i = 0; i < productos.length; i++) {
            System.out.println((i + 1) + ". " + productos[i] + " - S/." + precios[i]);
        }
        System.out.println("----------------------------------------");
        
        double ventaTotal = 0.0;
        int continuar = 1;
        
        do {
            System.out.print("\nSeleccione el producto (1-6): ");
            int opcion = scanner.nextInt();
            
            if (opcion >= 1 && opcion <= 6) {
                System.out.print("Ingrese la cantidad: ");
                int cantidad = scanner.nextInt();
                
                double subtotal = precios[opcion - 1] * cantidad;
                ventaTotal += subtotal;
                
                System.out.println("----------------------------------------");
                System.out.println("Producto: " + productos[opcion - 1]);
                System.out.println("Cantidad: " + cantidad);
                System.out.println("Subtotal: S/." + String.format("%.2f", subtotal));
                System.out.println("----------------------------------------");
            } else {
                System.out.println("❌ Opción inválida. Intente nuevamente.");
            }
            
            System.out.print("¿Desea registrar otra venta? (1=Sí, 0=No): ");
            continuar = scanner.nextInt();
            
        } while (continuar == 1);
        
        System.out.println("\n========================================");
        System.out.println("   RESUMEN DE VENTAS");
        System.out.println("========================================");
        System.out.println("Venta Total del Día: S/." + String.format("%.2f", ventaTotal));
        System.out.println("========================================");
        
        scanner.close();
    } 
}
