
package Semana5;

import java.util.Random;

public class Ejemplo06 {
   public static void main(String[] args) {
        Random random = new Random();
        
        System.out.println("========================================");
        System.out.println("   CONTROL DE STOCK ALEATORIO");
        System.out.println("   100 Productos (0-200 unidades)");
        System.out.println("========================================");
        
        int menor50 = 0;
        int entre50y100 = 0;
        int entre100y150 = 0;
        int mayor150 = 0;
        
        System.out.println("\nStock generado por producto:");
        System.out.println("----------------------------------------");
        
        for (int i = 1; i <= 100; i++) {
            int stock = random.nextInt(201);
            
            System.out.print("Producto " + String.format("%3d", i) + ": " + String.format("%3d", stock) + " unid.");
            
            if (i % 5 == 0) {
                System.out.println();
            } else {
                System.out.print(" | ");
            }
            
            if (stock < 50) {
                menor50++;
            } else if (stock >= 50 && stock < 100) {
                entre50y100++;
            } else if (stock >= 100 && stock < 150) {
                entre100y150++;
            } else {
                mayor150++;
            }
        }
        
        System.out.println("\n\n========================================");
        System.out.println("   RESUMEN DE STOCK");
        System.out.println("========================================");
        System.out.println("a. Productos con stock < 50:        " + menor50);
        System.out.println("b. Productos con stock >= 50 y < 100: " + entre50y100);
        System.out.println("c. Productos con stock >= 100 y < 150: " + entre100y150);
        System.out.println("d. Productos con stock >= 150:      " + mayor150);
        System.out.println("========================================");
        System.out.println("Total de productos: " + (menor50 + entre50y100 + entre100y150 + mayor150));
        System.out.println("========================================");
    }  
}
