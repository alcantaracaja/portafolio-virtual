
package semana05;

import java.util.Scanner;

public class Ejemplo03 {
   
        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("========================================");
        System.out.println("   ANÁLISIS DE DÍGITOS DE UN NÚMERO");
        System.out.println("========================================");
        
        System.out.print("Ingrese un número entero: ");
        int numero = scanner.nextInt();
        
        int numeroOriginal = Math.abs(numero);
        int cantidadDigitos = 0;
        int sumaPares = 0;
        int sumaImpares = 0;
        int temp = numeroOriginal;
        
        while (temp > 0) {
            int digito = temp % 10;
            cantidadDigitos++;
            
            if (digito % 2 == 0) {
                sumaPares += digito;
            } else {
                sumaImpares += digito;
            }
            
            temp = temp / 10;
        }
        
        System.out.println("\n========================================");
        System.out.println("Número ingresado: " + numero);
        System.out.println("Cantidad de dígitos: " + cantidadDigitos);
        System.out.println("Suma de dígitos pares: " + sumaPares);
        System.out.println("Suma de dígitos impares: " + sumaImpares);
        System.out.println("========================================");
        
        scanner.close();
    }
}
