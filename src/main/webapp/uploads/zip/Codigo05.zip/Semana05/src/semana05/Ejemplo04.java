
package semana05;

import java.util.Scanner;

public class Ejemplo04 {
  public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("========================================");
        System.out.println("   SERIE CON FACTORIAL (do...while)");
        System.out.println("   S = 1 - 2/2! + 3/3! - 4/4! + ...");
        System.out.println("========================================");
        
        System.out.print("Ingrese el número de términos (N): ");
        int n = scanner.nextInt();
        
        double suma = 0.0;
        int i = 1;
        
        do {
            double factorial = 1;
            int j = 1;
            
            do {
                factorial *= j;
                j++;
            } while (j <= i);
            
            double termino = (double) i / factorial;
            
            if (i % 2 == 0) {
                termino = -termino;
            }
            
            suma += termino;
            i++;
        } while (i <= n);
        
        System.out.println("\n========================================");
        System.out.println("Número de términos: " + n);
        System.out.println("Suma total de la serie: " + String.format("%.6f", suma));
        System.out.println("========================================");
        
        scanner.close();
    }  
}
