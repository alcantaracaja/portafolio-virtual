
package semana05;

import java.util.Scanner;

public class Ejemplo02 {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("========================================");
        System.out.println("   SERIE DE FRACCIONES: 2/5, 5/9...");
        System.out.println("========================================");
        
        System.out.print("Ingrese el número de términos (n): ");
        int n = scanner.nextInt();
        
        int numerador = 2;
        int denominador = 5;
        double suma = 0.0;
        
        System.out.println("\nSerie generada:");
        System.out.print("  ");
        
        for (int i = 1; i <= n; i++) {
            double valor = (double) numerador / denominador;
            System.out.print(numerador + "/" + denominador);
            if (i < n) {
                System.out.print(", ");
            }
            suma += valor;
            numerador += 3;
            denominador += 4;
        }
        
        System.out.println("\n\n========================================");
        System.out.println("Número de términos: " + n);
        System.out.println("Suma total de la serie: " + String.format("%.4f", suma));
        System.out.println("========================================");
        
        scanner.close();
    }
    
}
