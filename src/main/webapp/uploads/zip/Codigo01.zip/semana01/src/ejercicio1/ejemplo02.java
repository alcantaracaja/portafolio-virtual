
package ejercicio1;

import java.util.Scanner;

public class ejemplo02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 02: Área de un Círculo y Circunferencia");
        System.out.println("================================================");
        
        System.out.print("Ingrese el radio (r) del círculo: ");
        double r = scanner.nextDouble();
        
        // Fórmulas usando la constante pi = 3.1416 del enunciado
        double pi = 3.1416;
        double area = pi * r * r;
        double longitud = 2 * pi * r;
        
        System.out.println("\n---------------- Resultados ----------------");
        System.out.printf("Área (A)                    = %.4f\n", area);
        System.out.printf("Longitud Circunferencia (L) = %.4f\n", longitud);
        System.out.println("--------------------------------------------");
        
        scanner.close();
    }
}
