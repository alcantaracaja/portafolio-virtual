
package ejercicio1;

import java.util.Scanner;

public class ejemplo08 {
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 08: Convertir Segundos a Horas, Minutos y Segundos");
        System.out.println("================================================");
        
        System.out.print("Ingrese la cantidad total de segundos: ");
        long totalSegundos = scanner.nextLong();
        
        if (totalSegundos < 0) {
            System.out.println("\nError: Los segundos no pueden ser negativos.");
        } else {
            // Conversiones
            long horas = totalSegundos / 3600;
            long residuoSegundos = totalSegundos % 3600;
            long minutos = residuoSegundos / 60;
            long segundos = residuoSegundos % 60;
            
            System.out.println("\n---------------- Resultados ----------------");
            System.out.println("Segundos ingresados: " + totalSegundos);
            System.out.printf("Equivalente:         %d horas, %d minutos y %d segundos\n", horas, minutos, segundos);
            System.out.printf("Formato HH:MM:SS:    %02d:%02d:%02d\n", horas, minutos, segundos);
            System.out.println("--------------------------------------------");
        }
        
        scanner.close();
    }  
}
