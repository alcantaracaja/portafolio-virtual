
package ejercicio1;

import java.util.Scanner;

public class ejemplo06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 06: Cociente y Residuo de Dos Números");
        System.out.println("================================================");
        
        System.out.print("Ingrese el dividendo (entero): ");
        int dividendo = scanner.nextInt();
        
        System.out.print("Ingrese el divisor (entero): ");
        int divisor = scanner.nextInt();
        
        if (divisor == 0) {
            System.out.println("\nError: La división por cero no está definida.");
        } else {
            int cociente = dividendo / divisor;
            int residuo = dividendo % divisor;
            
            System.out.println("\n---------------- Resultados ----------------");
            System.out.println("Dividendo: " + dividendo);
            System.out.println("Divisor:   " + divisor);
            System.out.println("Cociente:  " + cociente);
            System.out.println("Residuo:   " + residuo);
            System.out.println("--------------------------------------------");
        }
        
        scanner.close();
    }
}
