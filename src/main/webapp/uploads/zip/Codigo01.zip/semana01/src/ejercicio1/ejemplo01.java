
package ejercicio1;

import java.util.Scanner;

public class ejemplo01 {
    
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 01: Área y Perímetro de un Rectángulo");
        System.out.println("================================================");
        
        System.out.print("Ingrese la base (b) del rectángulo: ");
        double b = scanner.nextDouble();
        
        System.out.print("Ingrese la altura (h) del rectángulo: ");
        double h = scanner.nextDouble();
        
        // Fórmulas
        double area = b * h;
        double perimetro = 2 * (b + h);
        
        System.out.println("\n---------------- Resultados ----------------");
        System.out.printf("Área (A)      = %.4f\n", area);
        System.out.printf("Perímetro (P) = %.4f\n", perimetro);
        System.out.println("--------------------------------------------");
        
        scanner.close();
    }
}
