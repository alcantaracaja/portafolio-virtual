
package ejercicio1;

import java.util.Scanner;

public class ejemplo05 {
    public class Proyecto05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 05: Área y Volumen de un Cubo");
        System.out.println("================================================");
        
        System.out.print("Ingrese la longitud del lado (a) del cubo: ");
        double a = scanner.nextDouble();
        
        // Fórmulas
        double area = 6 * a * a;
        double volumen = a * a * a;
        
        System.out.println("\n---------------- Resultados ----------------");
        System.out.printf("Área (A)    = %.4f\n", area);
        System.out.printf("Volumen (V) = %.4f\n", volumen);
        System.out.println("--------------------------------------------");
        
        scanner.close();
    }
}
}
