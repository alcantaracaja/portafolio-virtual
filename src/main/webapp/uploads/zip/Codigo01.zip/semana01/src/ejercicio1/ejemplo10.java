
package ejercicio1;

import java.util.Scanner;

public class ejemplo10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 10: Distribución de Presupuesto de Feria");
        System.out.println("================================================");
        
        System.out.print("Ingrese el monto total a invertir: ");
        double montoTotal = scanner.nextDouble();
        
        if (montoTotal < 0) {
            System.out.println("\nError: El monto a invertir no puede ser negativo.");
        } else {
            // Porcentajes definidos
            double pctAlquiler = 0.23;
            double pctPublicidad = 0.07;
            double pctTransporte = 0.26;
            double pctServicios = 0.12;
            double pctDecoracion = 0.21;
            double pctGastosVarios = 0.11;
            
            // Cálculos
            double alquiler = montoTotal * pctAlquiler;
            double publicidad = montoTotal * pctPublicidad;
            double transporte = montoTotal * pctTransporte;
            double servicios = montoTotal * pctServicios;
            double decoracion = montoTotal * pctDecoracion;
            double gastosVarios = montoTotal * pctGastosVarios;
            
            double totalGastado = alquiler + publicidad + transporte + servicios + decoracion + gastosVarios;
            
            System.out.println("\n---------------- Resultados ----------------");
            System.out.printf("Inversión Total: S/. %.2f\n\n", montoTotal);
            System.out.printf("1. Alquiler de espacio (23%%):   S/. %.2f\n", alquiler);
            System.out.printf("2. Publicidad (7%%):              S/. %.2f\n", publicidad);
            System.out.printf("3. Transporte (26%%):            S/. %.2f\n", transporte);
            System.out.printf("4. Servicios feriales (12%%):    S/. %.2f\n", servicios);
            System.out.printf("5. Decoración (21%%):            S/. %.2f\n", decoracion);
            System.out.printf("6. Gastos varios (11%%):         S/. %.2f\n", gastosVarios);
            System.out.println("--------------------------------------------");
            System.out.printf("Monto total distribuido:        S/. %.2f (100%%)\n", totalGastado);
            System.out.println("--------------------------------------------");
        }
        
        scanner.close();
    }
}
