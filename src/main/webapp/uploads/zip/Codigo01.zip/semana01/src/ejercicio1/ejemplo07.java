
package ejercicio1;

import java.util.Scanner;

public class ejemplo07 {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 07: Invertir Número de 5 Dígitos");
        System.out.println("================================================");
        
        System.out.print("Ingrese un número entero de 5 dígitos: ");
        int numero = scanner.nextInt();
        
        // Validación de que sea un número de 5 dígitos
        int valorAbsoluto = Math.abs(numero);
        if (valorAbsoluto < 10000 || valorAbsoluto > 99999) {
            System.out.println("\nError: El número ingresado no tiene exactamente 5 dígitos.");
        } else {
            // Extracción matemática de los dígitos
            int temp = valorAbsoluto;
            int d1 = temp % 10;       // Quinto dígito (unidades) -> se vuelve primero
            temp = temp / 10;
            int d2 = temp % 10;       // Cuarto dígito (decenas) -> se vuelve segundo
            temp = temp / 10;
            int d3 = temp % 10;       // Tercer dígito (centenas) -> se mantiene tercero
            temp = temp / 10;
            int d4 = temp % 10;       // Segundo dígito (millares) -> se vuelve cuarto
            temp = temp / 10;
            int d5 = temp % 10;       // Primer dígito (decenas de millar) -> se vuelve quinto
            
            // Reconstrucción del número invertido
            int invertido = d1 * 10000 + d2 * 1000 + d3 * 100 + d4 * 10 + d5;
            
            // Si el original era negativo, mantenemos el signo
            if (numero < 0) {
                invertido = -invertido;
            }
            
            System.out.println("\n---------------- Resultados ----------------");
            System.out.println("Número Original:  " + numero);
            System.out.println("Dígitos extraídos (de der. a izq.): " + d1 + ", " + d2 + ", " + d3 + ", " + d4 + ", " + d5);
            System.out.println("Número Invertido: " + invertido);
            System.out.println("--------------------------------------------");
        }
        
        scanner.close();
    }
}
