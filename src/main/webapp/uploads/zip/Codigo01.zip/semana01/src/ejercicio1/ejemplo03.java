
package ejercicio1;

    import java.util.Scanner;

public class ejemplo03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 03: Área de un Trapecio (Rombo en Enunciado)");
        System.out.println("================================================");
        
        System.out.print("Ingrese la base mayor (B): ");
        double B = scanner.nextDouble();
        
        System.out.print("Ingrese la base menor (b): ");
        double b = scanner.nextDouble();
        
        System.out.print("Ingrese la altura (h): ");
        double h = scanner.nextDouble();
        
        // Fórmula del enunciado: A = ((B + b) * h) / 2
        double area = ((B + b) * h) / 2.0;
        
        System.out.println("\n---------------- Resultados ----------------");
        System.out.printf("Área (A) = %.4f\n", area);
        System.out.println("--------------------------------------------");
        
        scanner.close();
    }
}
