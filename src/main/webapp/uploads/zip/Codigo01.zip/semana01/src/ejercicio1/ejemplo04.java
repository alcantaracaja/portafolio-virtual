
package ejercicio1;

import java.util.Scanner;

public class ejemplo04 {
     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 04: Área Total y Volumen de un Cilindro");
        System.out.println("================================================");
        
        System.out.print("Ingrese el radio (r) del cilindro: ");
        double r = scanner.nextDouble();
        
        System.out.print("Ingrese la altura (h) del cilindro: ");
        double h = scanner.nextDouble();
        
        // Fórmulas
        double area = 2 * Math.PI * r * (r + h);
        double volumen = Math.PI * r * r * h;
        
        System.out.println("\n---------------- Resultados ----------------");
        System.out.printf("Área Total (A) = %.4f\n", area);
        System.out.printf("Volumen (V)    = %.4f\n", volumen);
        System.out.println("--------------------------------------------");
        
        scanner.close();
    }
}
