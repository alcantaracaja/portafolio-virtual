
package ejercicio1;

import java.util.Scanner;

public class ejemplo09 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("================================================");
        System.out.println("Proyecto 09: Reparto de Dinero entre Hijos");
        System.out.println("================================================");
        
        System.out.print("Ingrese la cantidad de dinero a repartir: ");
        double montoTotal = scanner.nextDouble();
        
        if (montoTotal < 0) {
            System.out.println("\nError: El monto total no puede ser negativo.");
        } else {
            // Cálculos según reglas del enunciado:
            // 1. Josué: 27% de la cantidad a repartir
            double josue = 0.27 * montoTotal;
            
            // 2. Tamar: 85% del monto recibido por Josué
            double tamar = 0.85 * josue;
            
            // 3. Daniel: 25% de la cantidad a repartir
            double daniel = 0.25 * montoTotal;
            
            // 4. Caleb: 23% del monto total recibido entre Josué y Daniel
            double caleb = 0.23 * (josue + daniel);
            
            // 5. David: lo que queda del dinero a repartir
            double david = montoTotal - (josue + tamar + daniel + caleb);
            
            // Comprobación de suma total
            double sumaRepartida = josue + tamar + daniel + caleb + david;
            
            System.out.println("\n---------------- Resultados ----------------");
            System.out.printf("Monto Total a repartir: S/. %.2f\n\n", montoTotal);
            System.out.printf("• Josué (27%% del total):         S/. %.2f\n", josue);
            System.out.printf("• Tamar (85%% de Josué):          S/. %.2f\n", tamar);
            System.out.printf("• Daniel (25%% del total):        S/. %.2f\n", daniel);
            System.out.printf("• Caleb (23%% de Josué+Daniel):   S/. %.2f\n", caleb);
            System.out.printf("• David (El resto restante):     S/. %.2f\n", david);
            System.out.println("--------------------------------------------");
            System.out.printf("Suma total asignada:             S/. %.2f\n", sumaRepartida);
            System.out.println("--------------------------------------------");
        }
        
        scanner.close();
    }
}
