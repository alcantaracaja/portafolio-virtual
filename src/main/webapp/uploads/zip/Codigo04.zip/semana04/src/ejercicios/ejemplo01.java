
package ejercicios;

import java.util.Scanner;

public class ejemplo01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double tarifaDia = 0;
        double tarifaKm = 0;

        System.out.println("=== EMPRESA RENTA CAR ===");

        System.out.println("1. Auto pequeño");
        System.out.println("2. Auto mediano");
        System.out.println("3. Auto grande");

        System.out.print("Seleccione tipo de auto: ");
        int tipo = sc.nextInt();

        System.out.print("Cantidad de días: ");
        int dias = sc.nextInt();

        System.out.print("Kilómetros recorridos: ");
        double km = sc.nextDouble();


        if(tipo == 1){

            tarifaDia = 15;
            tarifaKm = 0.20;

        }else if(tipo == 2){

            tarifaDia = 20;
            tarifaKm = 0.30;

        }else if(tipo == 3){

            tarifaDia = 30;
            tarifaKm = 0.40;

        }else{

            System.out.println("Tipo de auto incorrecto");
            return;

        }


        double total = (tarifaDia * dias) + (tarifaKm * km);


        if(km > 10){

            total = total + (total * 0.025);

        }


        System.out.println("Total a pagar: S/." + total);

    }
}
