
package ejercicios;

import java.util.Scanner;

public class ejemplo02 {
    
     public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Horas trabajadas: ");
        double horas = sc.nextDouble();

        System.out.print("Pago por hora: ");
        double pagoHora = sc.nextDouble();


        double total;


        if(horas <= 40){

            total = horas * pagoHora;

        }else{

            double extras = horas - 40;


            if(extras <= 8){

                total = (40 * pagoHora) 
                      + (extras * pagoHora * 2);

            }else{

                total = (40 * pagoHora)
                      + (8 * pagoHora * 2)
                      + ((extras - 8) * pagoHora * 3);

            }

        }


        System.out.println("Pago total: S/." + total);

    }
}
