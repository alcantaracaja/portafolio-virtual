
package ejercicios;

import java.util.Scanner;

public class ejemplo03 {
    
      public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        System.out.print("Ingrese día: ");
        String dia = sc.nextLine().toLowerCase();


        System.out.print("Hora entrada: ");
        int he = sc.nextInt();

        System.out.print("Minuto entrada: ");
        int me = sc.nextInt();


        System.out.print("Hora salida: ");
        int hs = sc.nextInt();

        System.out.print("Minuto salida: ");
        int ms = sc.nextInt();


        int entrada = he * 60 + me;

        int salida = hs * 60 + ms;


        int minutos = salida - entrada;


        int horas = minutos / 60;


        if(minutos % 60 != 0){

            horas++;

        }


        double tarifa;


        if(dia.equals("lunes") ||
           dia.equals("martes") ||
           dia.equals("miercoles") ||
           dia.equals("jueves")){

            tarifa = 3.5;


        }else if(dia.equals("viernes") ||
                 dia.equals("sabado")){

            tarifa = 4.5;


        }else{

            tarifa = 2.5;

        }


        double pago = horas * tarifa;


        System.out.println("Horas usadas: " + horas);

        System.out.println("Pago total: S/." + pago);

    }
      
}
