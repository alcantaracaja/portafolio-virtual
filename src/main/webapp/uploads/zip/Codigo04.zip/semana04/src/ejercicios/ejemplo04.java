
package ejercicios;

import java.util.Scanner;

public class ejemplo04 {
    
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);


        System.out.print("Nota práctica 1: ");
        double n1 = sc.nextDouble();


        System.out.print("Nota práctica 2: ");
        double n2 = sc.nextDouble();


        System.out.print("Nota práctica 3: ");
        double n3 = sc.nextDouble();



        if(n3 >= 10){

            n3 = n3 + 2;

        }


        double promedio = (n1+n2+n3)/3;


        if(promedio > 20){

            promedio = 20;

        }


        System.out.println(
        "Promedio final: " + promedio);

    }
    
}
